# -*- coding: utf-8 -*-
"""
Created on Wed Dec 18 16:55:00 2019

@author: 老吴
"""

import pandas as pd
import matplotlib
import matplotlib.pyplot as plt

if __name__=='__main__':
    #读取数据
    data=pd.read_csv('C:/Users/44839/Desktop/学生校园消费行为/分析总结/task1_1_X.csv')
    #决绝汉字乱码问题
    matplotlib.rcParams['font.sans-serif']=['SimHei'] #指定汉字的汉字字体类型，此处为黑体
    
    #计算18级整体学生本月的人均刷卡频次和人均消费
    consume_data=data.groupby('CardNo')['Money'].sum()
    print('18级整体学生本月的人均消费:',consume_data.values.mean())
    card_data=data.groupby('CardNo')['CardCount'].count()
    print('18级整体学生本月的人均刷卡频次',card_data.values.mean())
    
    #不同专业间不同性别学生群体的消费特点
    
    #获取专业列表
    majors=data.drop_duplicates(subset='Major',keep='first',inplace=False)['Major'].values
    #print(majors)
        
    #处理不同专业整体学生人均刷卡频次与人均消费
    majors_data=[]
    for major in majors:
        majors_data.append(data.groupby('Major').get_group(major).reset_index())
    #print(majors_data)
    
    consumes_data=[]
    cards_data=[]
    for major,major_data in zip(majors,majors_data):
        consume_data=major_data.groupby('CardNo')['Money'].sum()
        consumes_data.append(consume_data.values.mean())
        card_data=major_data.groupby('CardNo')['CardCount'].count()
        cards_data.append(card_data.values.mean())
        #print(major,'学生本月的人均消费:',consume_data.values.mean())
        #print(major,'学生本月的人均刷卡频次',card_data.values.mean())
        
        
    #处理不同专业不同性别学生人均刷卡频次与人均消费    
    majors_sex_data=[]
    for major,major_data in zip(majors,majors_data):  
        major_sex_data=[]
        major_sex_data.append(major_data.loc[major_data['Sex']=='男'])
        major_sex_data.append(major_data.loc[major_data['Sex']=='女'])
        majors_sex_data.append(major_sex_data)
    #print(majors_sex_data)
            
    consumes_sex_data=[]
    cards_sex_data=[]
    for major,major_sex_data in zip(majors,majors_sex_data):
        consume_sex_data=[]
        card_sex_data=[]   
        for major_data in major_sex_data:
            sex=major_data.drop_duplicates(subset='Sex',keep='first',inplace=False)['Sex'].values
            consume_data=major_data.groupby('CardNo')['Money'].sum()
            consume_sex_data.append(consume_data.values.mean())
            card_data=major_data.groupby('CardNo')['CardCount'].count()
            card_sex_data.append(card_data.values.mean())
            #print(major,sex,'学生本月的人均消费:',consume_data.values.mean())
            #print(major,sex,'学生本月的人均刷卡频次',card_data.values.mean())
        consumes_sex_data.append(consume_sex_data)
        cards_sex_data.append(card_sex_data)
        #绘制柱形图
        x=[]
        for major_data in major_sex_data:
            if major_data.size==0:
                continue;
            x.append(major_data.drop_duplicates(subset='Sex',keep='first',inplace=False)['Sex'].values[0])
        
        y=consume_sex_data
        plt.title(major)
        plt.bar(x,y)
        plt.savefig('C:/Users/44839/Desktop/学生校园消费行为/分析总结/result/[%s]男女生人均消费对比柱形图.png'%major)
        plt.show()  
          
        