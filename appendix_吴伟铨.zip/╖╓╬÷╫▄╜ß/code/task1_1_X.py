# -*- coding: utf-8 -*-
"""
Created on Tue Dec 10 20:29:29 2019

@author: 老吴
"""

import pandas as pd
if __name__ == '__main__':
    #读取经过处理后的学生个人信息表与消费记录表
    data1=pd.read_csv('C:/Users/44839/Desktop/学生校园消费行为/分析总结/task1_X1.csv')
    data2=pd.read_csv('C:/Users/44839/Desktop/学生校园消费行为/分析总结/task1_X2.csv');
    
    #主键合并（内连接）
    data=pd.merge(left=data1,right=data2,on='CardNo')
    #print(data)
    list1=['Index']
    data1=data.drop(labels=list1,axis=1)
    print(data1)
    #保存数据
    data1.to_csv('C:/Users/44839/Desktop/学生校园消费行为/分析总结/task1_1_X.csv',index=False)