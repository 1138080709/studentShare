# -*- coding: utf-8 -*-
"""
Created on Thu Dec 19 01:32:26 2019

@author: 老吴
"""

import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt


if __name__=='__main__':
    #根据学生的整体校园消费分析
    #读取整体数据
    data=pd.read_csv('C:/Users/44839/Desktop/学生校园消费行为/任务1.1/result/task1_X2.csv')
    #FM模型（F:消费频率 M:消费金额）
    #统计每个学生的月消费频率与消费金额 生成新数据表
    new_data_consume=data.groupby('CardNo')['Money'].sum().reset_index()
    new_data_card=data.groupby('CardNo')['CardCount'].count().reset_index()
    new_data=pd.merge(left=new_data_card,right=new_data_consume,on='CardNo')
    print(new_data)
    new_data.to_csv('C:/Users/44839/Desktop/学生校园消费行为/任务3.2/result/task1_X1.csv',index=False)
    
    model_data=new_data[['CardCount','Money']].values
    #标准化处理数据
    model=StandardScaler().fit(model_data)
    model_data_ss=model.transform(model_data)
    
    #print(model_data)
    
    print('ARI评价法(兰德系数)')
    for k in range(2,9):
        model =KMeans(n_clusters=k).fit(model_data_ss)
        print(k,silhouette_score(model_data_ss,model.labels_))
    
   
    
    model=KMeans(n_clusters=3).fit(model_data_ss)
    print(model.labels_)
    print(model.cluster_centers_)
    for i in range(3):
        plt.scatter(model_data[model.labels_==i,0],model_data[model.labels_==i,1])
    plt.title('聚类效果图')
    plt.xlabel('消费频率')
    plt.ylabel('消费金额')
    plt.savefig('C:/Users/44839/Desktop/学生校园消费行为/任务3.2/result/聚类效果图.png')
    plt.show()
    
    
    
