# -*- coding: utf-8 -*-
"""
Created on Wed Dec 18 03:29:28 2019

@author: 老吴
"""
    #任务2.2
    
    
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
    
#筛选食堂的消费记录
def canteen_filter(all_data):
    data=[]
    canteens=['第一食堂','第二食堂','第三食堂','第四食堂','第五食堂','教师食堂']
    for i in canteens:
        data.append(all_data.loc[all_data['Dept']==i])
        #data.append(data1.groupby('Dept').get_group(i).reset_index())
    return data


if __name__ == '__main__':
    #决绝汉字乱码问题
    matplotlib.rcParams['font.sans-serif']=['SimHei'] #指定汉字的汉字字体类型，此处为黑体
    #读取数据
    data3=pd.read_csv('C:/Users/44839/Desktop/学生校园消费行为/分析总结/task2_X1.csv')
    #提取工作日
    workday_data1=data3.loc[data3['Day']==28]
    workday_data2=data3.loc[data3['Day']!=5]
    workday_data2=workday_data2.loc[workday_data2['Week']<=5]
    workday_data=pd.concat([workday_data1,workday_data2])
    print(workday_data.shape)
    #工作日的天数
    workday_num=workday_data.groupby('Day')['Day'].nunique().sum()
    print(workday_num)
    
    
    #计算所有食堂工作日的就餐频数
    workday_sum=[]
    for j in range(0,24):
        temp=workday_data[workday_data['lab']==1]
        temp=temp[temp['Hour']==j]
        workday_sum.append(temp['lab'].sum())
    print(workday_sum)
    
    #划分食堂
    workday_data3=canteen_filter(workday_data)
    hours_sum=[]
    for i in workday_data3:
        #计算小时的就餐频数
        hour_sum=[]
        for j in range(0,24):
            temp=i[i['lab']==1]
            temp=temp[temp['Hour']==j]
            hour_sum.append(temp['lab'].sum())
        hours_sum.append(hour_sum)
    print(hours_sum)
        
    #绘制日均曲线图
    x=range(0,24)
    y0=[(y/workday_num)/6 for y in workday_sum]
    y1=[y/workday_num for y in hours_sum[0]]
    #print(y1)
    y2=[y/workday_num for y in hours_sum[1]]
    y3=[y/workday_num for y in hours_sum[2]]
    y4=[y/workday_num for y in hours_sum[3]]
    y5=[y/workday_num for y in hours_sum[4]]
    y6=[y/workday_num for y in hours_sum[5]]
    plt.title('食堂工作日就餐折线图')
    plt.xlabel('时间/小时')
    plt.ylabel('日平均就餐人次')
    plt.xticks(x)
    
    plt.plot(x,y1,label='第一食堂')
    plt.plot(x,y2,label='第二食堂')
    plt.plot(x,y3,label='第三食堂')
    plt.plot(x,y4,label='第四食堂')
    plt.plot(x,y5,label='第五食堂')
    plt.plot(x,y6,label='教师食堂')
    plt.plot(x,y0,label='水平趋势')
    plt.legend()
    plt.savefig('C:/Users/44839/Desktop/学生校园消费行为/分析总结/result/食堂工作日就餐折线图.png')
    plt.show()
            
    
    #提取非工作日
    unworkday_data1=data3.loc[data3['Day']==5]
    unworkday_data2=data3.loc[data3['Day']!=28]
    unworkday_data2=unworkday_data2.loc[data3['Week']>5]
    unworkday_data=pd.concat([unworkday_data1,unworkday_data2])
    
    #非工作日的天数
    unworkday_num=unworkday_data.groupby('Day')['Day'].nunique().sum()
    #print(workday_num)
    
    #计算所有食堂非工作日的就餐频数
    unworkday_sum=[]
    for j in range(0,24):
        temp=unworkday_data[unworkday_data['lab']==1]
        temp=temp[temp['Hour']==j]
        unworkday_sum.append(temp['lab'].sum())
    print(unworkday_sum)
    
    #划分食堂
    unworkday_data3=canteen_filter(unworkday_data)
    hours_sum=[]
    for i in unworkday_data3:
        #计算小时的就餐频数
        hour_sum=[]
        for j in range(0,24):
            temp=i[i['lab']==1]
            temp=temp[temp['Hour']==j]
            hour_sum.append(temp['lab'].sum())
        hours_sum.append(hour_sum)
    #print(hours_sum)
        
    #绘制日均曲线图
    x=range(0,24)
    y0=[(y/unworkday_num)/6 for y in unworkday_sum]
    y1=[y/unworkday_num for y in hours_sum[0]]
    #print(y1)
    y2=[y/unworkday_num for y in hours_sum[1]]
    y3=[y/unworkday_num for y in hours_sum[2]]
    y4=[y/unworkday_num for y in hours_sum[3]]
    y5=[y/unworkday_num for y in hours_sum[4]]
    y6=[y/unworkday_num for y in hours_sum[5]]
    plt.title('食堂非工作日就餐折线图')
    plt.xlabel('时间/小时')
    plt.ylabel('日平均就餐人次')
    plt.xticks(x)
    plt.plot(x,y0,label='水平趋势')
    plt.plot(x,y1,label='第一食堂')
    plt.plot(x,y2,label='第二食堂')
    plt.plot(x,y3,label='第三食堂')
    plt.plot(x,y4,label='第四食堂')
    plt.plot(x,y5,label='第五食堂')
    plt.plot(x,y6,label='教师食堂')
    plt.legend()
    plt.savefig('C:/Users/44839/Desktop/学生校园消费行为/分析总结/result/食堂非工作日就餐折线图.png')
    plt.show()
