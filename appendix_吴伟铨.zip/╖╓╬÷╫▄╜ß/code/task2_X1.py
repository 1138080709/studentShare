# -*- coding: utf-8 -*-
"""
Created on Wed Dec 11 11:57:42 2019

@author: 老吴
"""

import pandas as pd
import matplotlib
import matplotlib.pyplot as plt


#筛选食堂的消费记录
def canteen_filter(all_data):
    data=[]
    canteens=['第一食堂','第二食堂','第三食堂','第四食堂','第五食堂','教师食堂']
    for i in canteens:
        data.append(all_data.loc[all_data['Dept']==i])
        #data.append(data1.groupby('Dept').get_group(i).reset_index())
    return data


if __name__ == '__main__':
    #读取数据
    data1=pd.read_csv('C:/Users/44839/Desktop/学生校园消费行为/分析总结/task1_X2.csv')
    #去除Unnamed列
    #data1=data.iloc[:,1:8]

    #学号时间排序
    sort=['CardNo','Date']
    data1.sort_index(by=sort,ascending=True,inplace=True)
    #提取时间
    #转化Date类的数据类型
    data1['Date']=pd.to_datetime(data1['Date'])
    #提取星期
    data1['Week']=data1['Date'].apply(lambda x:x.weekday()+1)
    #提取天
    data1['Day']=[i.day for i in data1['Date']]
    #提取时
    data1['Hour']=data1['Date'].dt.hour
    #提取分
    data1['Minute']=data1['Date'].dt.minute
    #标记就餐人次
    data1['lab']=0
     #筛选食堂记录
    data2=canteen_filter(data1)
    for i in data2:
        #标记不同学号不同天的记录 
        i['lab']=i.groupby(['CardNo','Day'])['lab'].shift(1)
        i['lab']=i['lab'].fillna(1)
        #标记不同小时不同分钟的记录
        for j in range(1,len(i)):
            if i['lab'].iloc[j]==1:
                continue
            if i['Hour'].iloc[j]==i['Hour'].iloc[j-1]:
                temp=abs(i['Minute'].iloc[j]-i['Minute'].iloc[j-1])
                if temp>10:
                    i['lab'].iloc[j]=1
            if i['Hour'].iloc[j]!=i['Hour'].iloc[j-1]:
                temp=abs((i['Hour'].iloc[j]*24+i['Minute'].iloc[j])-(i['Hour'].iloc[j-1]*24+i['Minute'].iloc[j-1]))
                if temp>10:
                    i['lab'].iloc[j]=1
            
            
    data3=pd.concat(data2)
    
    data3.to_csv('C:/Users/44839/Desktop/学生校园消费行为/分析总结/task2_X1.csv',index=False)
    
    #决绝汉字乱码问题
    matplotlib.rcParams['font.sans-serif']=['SimHei'] #指定汉字的汉字字体类型，此处为黑体
    
    data4=canteen_filter(data3)
    #计算各个食堂的累计就餐次数
    sums=[]
    for i in data4:
        temp=i[i['lab']==1]
        sums.append(temp['lab'].sum())
    print(sums)
    
    
    
    #各食堂就餐人次的总占比饼图
    plt.figure(figsize=(4,4))
    plt.title('总占比饼图')
    plt.pie(sums,autopct='%.2f%%',labels=['第一食堂','第二食堂','第三食堂','第四食堂','第五食堂','教师食堂'],labeldistance=1.1)
    plt.legend()
    plt.savefig('C:/Users/44839/Desktop/学生校园消费行为/分析总结/result/总占比饼图.png')
    plt.show()
    
    #早餐
    breakfast_data=data3.loc[data3['Hour']>=7]
    breakfast_data=breakfast_data.loc[breakfast_data['Hour']<=9]
    breakfast_data1=canteen_filter(breakfast_data)
    #计算各个食堂的累计就餐次数
    sums=[]
    for i in breakfast_data1:
        temp=i[i['lab']==1]
        sums.append(temp['lab'].sum())
    print(sums)
    
    #各食堂就餐人次的占比饼图
    plt.figure(figsize=(4,4))
    plt.title('早餐占比饼图')
    plt.pie(sums,autopct='%.2f%%',labels=['第一食堂','第二食堂','第三食堂','第四食堂','第五食堂','教师食堂'],labeldistance=1.1)
    plt.legend()
    plt.savefig('C:/Users/44839/Desktop/学生校园消费行为/分析总结/result/早餐占比饼图.png')
    plt.show()
    
    #午餐
    lunch_data=data3.loc[data3['Hour']>=11]
    lunch_data=lunch_data.loc[lunch_data['Hour']<=13]
    lunch_data1=canteen_filter(lunch_data)
    #计算各个食堂的累计就餐次数
    sums=[]
    for i in lunch_data1:
        temp=i[i['lab']==1]
        sums.append(temp['lab'].sum())
    print(sums)
    
    #各食堂就餐人次的占比饼图
    plt.figure(figsize=(4,4))
    plt.title('午餐占比饼图')
    plt.pie(sums,autopct='%.2f%%',labels=['第一食堂','第二食堂','第三食堂','第四食堂','第五食堂','教师食堂'],labeldistance=1.1)
    plt.legend()
    plt.savefig('C:/Users/44839/Desktop/学生校园消费行为/分析总结/result/午餐占比饼图.png')
    plt.show()
    
     #晚餐
    dinner_data=data3.loc[data3['Hour']>=18]
    dinner_data=dinner_data.loc[dinner_data['Hour']<=20]
    dinner_data1=canteen_filter(dinner_data)
    #计算各个食堂的累计就餐次数
    sums=[]
    for i in dinner_data1:
        temp=i[i['lab']==1]
        sums.append(temp['lab'].sum())
    print(sums)
    
    #各食堂就餐人次的占比饼图
    plt.figure(figsize=(4,4))
    plt.title('晚餐占比饼图')
    plt.pie(sums,autopct='%.2f%%',labels=['第一食堂','第二食堂','第三食堂','第四食堂','第五食堂','教师食堂'],labeldistance=1.1)
    plt.legend()
    plt.savefig('C:/Users/44839/Desktop/学生校园消费行为/分析总结/result/晚餐占比饼图.png')
    plt.show()