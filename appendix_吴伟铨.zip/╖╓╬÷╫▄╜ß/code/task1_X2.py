# -*- coding: utf-8 -*-
"""
Created on Mon Dec  9 16:13:29 2019

@author: 老吴
"""

import pandas as pd
import matplotlib.pyplot as plt

if __name__ == '__main__':
    #读取数据
    data=pd.read_csv("C:/Users/44839/Desktop/学生校园消费行为/data2.csv",encoding='gbk')
    #筛选消费类型的数据
    data1=data[data['Type']=='消费']
    #print(data1)
    
    #删除不需要的特征
    column=['PeoNo','TermSerNo','conOperNo','Type','FundMoney']
    data2=data1.drop(labels=column,axis=1)
    #print(data2)
    
    #缺失值统计
    print(data2.isnull().sum())
    
    #重复值统计
    data3=data2.drop_duplicates(subset='Index',keep="first")
    print("去重前的记录:",data2.shape)
    print("去重后的记录:",data3.shape)
    
    #描述性统计
    column1=['Money','Surplus','CardCount']
    data4=data3.loc[:,column1]
    #print(data4.describe())
    
    #异常值分析
    plt.boxplot(data4.loc[:,'Money'])
    plt.show()
    
    #异常夜间数据
    data3['Date']=pd.to_datetime(data3['Date'])
    data3['Hour']=data3['Date'].dt.hour
    data3=data3[data3['Hour']>6]
    data3=data3[data3['Hour']<23]
    data5=data3.drop(labels='Hour',axis=1)
    #print(data5)
    
    #保存数据
    data5.to_csv('C:/Users/44839/Desktop/学生校园消费行为/分析总结/task1_X2.csv',index=False)

