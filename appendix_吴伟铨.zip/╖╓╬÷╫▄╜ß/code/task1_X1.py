# -*- coding: utf-8 -*-
"""
Created on Mon Dec  9 14:35:31 2019

@author: 老吴
"""

import pandas as pd

if __name__ == '__main__':
    data1=pd.read_csv('C:/Users/44839/Desktop/学生校园消费行为/data1.csv',encoding='gbk')
    #查缺
    print(data1.isnull().sum())
    #去重
    data2=data1.drop_duplicates(subset='CardNo',keep='first',inplace=False)
    print("去重前的记录:",data1.shape)
    print("去重后的记录:",data2.shape)
    #去除无用列
    data3=data2.drop(labels='Index',axis=1)
    data4=data3.drop(labels='AccessCardNo',axis=1)
    #保存数据
    data4.to_csv("C:/Users/44839/Desktop/学生校园消费行为/分析总结/task1_X1.csv",index=False)